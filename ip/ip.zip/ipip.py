import os
import progressbar
import time
import folium
import requests
import json

print('\033[32m'+"THe ip OAF_1!GAJ+@!G-da cuda")
ip = input("")
bar = progressbar.ProgressBar()
for i in bar(range(100)):
    time.sleep(0.01)

def getLocationFromIP(ipaddr):
    url = "http://api.ipstack.com/"+ipaddr+"?access_key=86a7ae446e6b9259f536e547dec570dc"
    result = json.loads(requests.get(url).text)
    #print(result)
    return result

if __name__ == '__main__':
    result = getLocationFromIP(ip)
    dok = "lili"
    daee = result, dok

lat = float(result['latitude'])
lng = float(result['longitude'])

 #여기서부터 매블 열어용ㅎㅎ></
m = folium.Map(location=[lat, lng],
	tiles="OpenStreetMap",
    zoom_start=15)
    
folium.Marker(location=[lat, lng], icon=folium.Icon(color='red')).add_to(m)

dir = os.getcwd().replace("\\dist", "")
if os.path.isfile(dir+"map.html"):
    os.remove(dir+'map.html')

m.save('map.html')
os.system("map.html")